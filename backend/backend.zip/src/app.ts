import dotenv from "dotenv";
import express from "express";
import cors from "cors";
import routes from "./routes";
import { errorHandler } from "./middlewares/errorHandler";

dotenv.config();

const app = express();

const allowedOrigins = (process.env.ALLOWED_ORIGINS?.split(",") || [
	"http://localhost:3010",
	"http://localhost:3011",
	"http://localhost:3012",
	"http://localhost:3013",
	"http://localhost:3014",
]);

app.use(
	cors({
		origin: allowedOrigins,
		credentials: true,
		methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
		allowedHeaders: ["Content-Type", "Authorization"],
	})
);
// Preflight handled by CORS middleware; no global wildcard needed on Express 5
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (_req, res) => res.json({ success: true, message: "HR-UKK API" }));

app.use("/api", routes);

app.use(errorHandler);

export default app;
