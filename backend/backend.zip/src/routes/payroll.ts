import { Router } from "express";
import { 
  getAllPayroll, 
  getPayrollByEmployee, 
  generatePayroll, 
  generatePayslip, 
  downloadPayslip,
  getPayrollByMonth
} from "../controllers/payrollController";
import { authMiddleware } from "../middlewares/authMiddleware";
import { requireRole } from "../middlewares/roleMiddleware";
import { UserRole } from "@prisma/client";

const router = Router();

router.use(authMiddleware);

// GET all payroll (Admin/HR/Finance)
router.get("/", 
  requireRole([UserRole.ADMIN, UserRole.HR, UserRole.FINANCE]), 
  getAllPayroll
);

// GET payroll by employee
router.get("/employee/:id_employee", getPayrollByEmployee);

// GET payroll by month ?periode_month=2026-02
router.get("/month", getPayrollByMonth);

// GENERATE payroll periode baru
router.post("/generate", 
  requireRole([UserRole.ADMIN, UserRole.HR, UserRole.FINANCE]), 
  generatePayroll
);

// GENERATE payslip dari payroll
router.post("/payslip/:id_payroll", generatePayslip);

// DOWNLOAD payslip PDF
router.get("/payslip/:id_payslip", downloadPayslip);

export default router;
