import { Router } from "express";
import { listUsers, createUser, updateUser, deleteUser } from "../controllers/usersController";
import { authMiddleware } from "../middlewares/authMiddleware";
import { requireRole } from "../middlewares/roleMiddleware";
import { UserRole } from "@prisma/client";

const router = Router();

// Semua endpoint butuh auth
router.use(authMiddleware);

// HR boleh melihat daftar user (untuk assign karyawan),
// tapi hanya ADMIN yang boleh membuat / mengubah / menghapus user.
router.get("/", requireRole([UserRole.ADMIN, UserRole.HR]), listUsers);
router.post("/", requireRole([UserRole.ADMIN]), createUser);
router.put("/:id", requireRole([UserRole.ADMIN]), updateUser);
router.delete("/:id", requireRole([UserRole.ADMIN]), deleteUser);

export default router;
