import { Router } from "express";
import { login, register } from "../controllers/authController";
import { authMiddleware } from "../middlewares/authMiddleware";
import { requireRole } from "../middlewares/roleMiddleware";
import { UserRole } from "@prisma/client";

const router = Router();

router.post("/login", login);
router.post("/register", authMiddleware, requireRole([UserRole.ADMIN, UserRole.HR]), register);

export default router;
