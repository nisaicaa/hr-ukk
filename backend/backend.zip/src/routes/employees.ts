import { Router } from "express";
import { 
  getEmployees, 
  createEmployee, 
  bulkImport, 
  updateEmployee, 
  deleteEmployee 
} from "../controllers/employeesController";
import upload from '../utils/multer';

const router = Router();

router.get("/", getEmployees);
router.get("/list", getEmployees);
router.post("/", createEmployee);
router.post("/bulk", upload.single('excel'), bulkImport);
router.put("/:id", updateEmployee);
router.delete("/:id", deleteEmployee);


export default router;
