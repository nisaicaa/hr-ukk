import prisma from "../utils/prisma";
import { LeaveStatus, LeaveType } from "@prisma/client";

export async function createLeave(data: {
  id_employee: number;
  leave_type: LeaveType;
  start_date: Date;
  end_date: Date;
  reason: string;
  attachment?: string;
}) {
  return prisma.leave.create({
    data: {
      ...data,
      leave_status: LeaveStatus.PENDING,
    },
  });
}

export async function getLeaveByEmployee(id_employee: number) {
  return prisma.leave.findMany({
    where: { id_employee },
    orderBy: { created_at: "desc" },
  });
}

export async function getAllLeave() {
  return prisma.leave.findMany({
    include: {
      employee: {
        include: {
          user: true,
        },
      },
    },
    orderBy: { created_at: "desc" },
  });
}

export async function updateLeaveStatus(
  id_leave: number,
  status: LeaveStatus,
  approved_by: string
) {
  return prisma.leave.update({
    where: { id_leave },
    data: {
      leave_status: status,
      approved_by,
      approved_date: new Date(),
    },
  });
}