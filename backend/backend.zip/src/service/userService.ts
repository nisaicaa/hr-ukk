import prisma from "../utils/prisma";
import { UserRole } from "@prisma/client";

export async function getAllUsers() {
  return prisma.users.findMany({ select: { id_user: true, username: true, email: true, role: true, created_at: true } });
}

// User dengan role EMPLOYEE yang belum punya record employee sama sekali
export async function getUsersWithoutEmployee() {
  return prisma.users.findMany({
    where: {
      role: UserRole.EMPLOYEE,
      employee: { none: {} },
    },
    select: {
      id_user: true,
      username: true,
      email: true,
      role: true,
    },
  });
}

export async function createUser(data: { username: string; email: string; password: string; role: UserRole }) {
  return prisma.users.create({ data });
}

export async function findUserByEmail(email: string) {
  return prisma.users.findUnique({ where: { email } });
}

export async function findUserByUsername(username: string) {
  return prisma.users.findUnique({ where: { username } });
}

export async function findUserById(id_user: number) {
  return prisma.users.findUnique({ where: { id_user } });
}

export async function updateUserById(id_user: number, data: any) {
  return prisma.users.update({ where: { id_user }, data });
}

export async function deleteUserById(id_user: number) {
  return prisma.users.delete({ where: { id_user } });
}
