import prisma from "../utils/prisma";
import { UserRole } from "@prisma/client";
import xlsx from 'xlsx';
import bcrypt from 'bcrypt';

// Password sesuai permintaan Anda
const DEFAULT_PASSWORD = 'humanest26';

export async function listEmployees() {
  return prisma.employee.findMany({
    include: {
      user: {
        select: { id_user: true, username: true, email: true, role: true }
      }
    }
  });
}

export async function createEmployeeWithUser(data: any) {
  const hashedPassword = await bcrypt.hash(DEFAULT_PASSWORD, 10);
  return prisma.$transaction(async (tx) => {
    const user = await tx.users.create({
      data: {
        username: data.nik,
        email: data.email.toLowerCase(),
        password: hashedPassword,
        role: UserRole.EMPLOYEE
      }
    });

    return tx.employee.create({
      data: {
        id_user: user.id_user,
        departemen: data.departemen || 'Umum',
        jabatan: data.jabatan || 'Staff',
        birth_date: new Date('2000-01-01'),
        hire_date: new Date(),
        employee_status: 'AKTIF',
        basic_salary: Number(data.basic_salary) || 0,
      }
    });
  });
}

// FIX: Fungsi Update Lengkap
export async function updateEmployeeById(id: number, data: any) {
  return prisma.$transaction(async (tx) => {
    const current = await tx.employee.findUnique({
      where: { id_employee: id },
      include: { user: true }
    });

    if (!current) throw new Error("Karyawan tidak ditemukan");

    // Update User (Email & Username/NIK)
    await tx.users.update({
      where: { id_user: current.id_user },
      data: {
        email: data.email,
        username: data.nik
      }
    });

    // Update Detail Employee & Status
    return tx.employee.update({
      where: { id_employee: id },
      data: {
        departemen: data.departemen,
        jabatan: data.jabatan,
        basic_salary: Number(data.basic_salary),
        employee_status: data.employee_status || current.employee_status
      }
    });
  });
}

export async function deleteEmployeeById(id: number) {
  return prisma.$transaction(async (tx) => {
    const emp = await tx.employee.findUnique({ where: { id_employee: id } });
    if (!emp) throw new Error("Data tidak ditemukan");
    await tx.employee.delete({ where: { id_employee: id } });
    await tx.users.delete({ where: { id_user: emp.id_user } });
  });
}

// TETAP MENJAGA FUNGSI BULK IMPORT ANDA
export async function bulkImportEmployees(filePath: string) {
  const workbook = xlsx.readFile(filePath);
  const sheetName = workbook.SheetNames[0];
  const data: any[] = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);
  
  const results: any[] = [];
  const errors: string[] = [];
  const hashed = await bcrypt.hash(DEFAULT_PASSWORD, 10);

  for (const [index, row] of data.entries()) {
    try {
      const rowNum = index + 2;
      const nik = (row.nik || row.username || row.nip)?.toString().trim();
      const email = (row.email || row.mail)?.toString().trim().toLowerCase();

      if (!nik || !email) {
        errors.push(`Baris ${rowNum}: NIK/Email kosong`);
        continue;
      }

      const exist = await prisma.users.findFirst({
        where: { OR: [{ username: nik }, { email }] }
      });

      if (exist) {
        errors.push(`Baris ${rowNum}: NIK/Email ${nik} sudah ada`);
        continue;
      }

      await prisma.$transaction(async (tx) => {
        const u = await tx.users.create({
          data: { username: nik, email, password: hashed, role: UserRole.EMPLOYEE }
        });
        await tx.employee.create({
          data: {
            id_user: u.id_user,
            departemen: (row.departemen || row.dept || "Umum").toString(),
            jabatan: (row.jabatan || row.posisi || "Staff").toString(),
            birth_date: new Date('2000-01-01'),
            hire_date: new Date(),
            employee_status: 'AKTIF',
            basic_salary: Number(row.basic_salary || row.gaji) || 0
          }
        });
      });
      results.push(nik);
    } catch (err: any) {
      errors.push(`Baris ${index + 2}: ${err.message}`);
    }
  }
  return { summary: `${results.length} berhasil, ${errors.length} gagal`, errors, password: DEFAULT_PASSWORD };
}
// Tambahkan fungsi ini di paling bawah file backend/src/service/employeeService.ts

// Tambahkan/Update fungsi ini di paling bawah file backend/src/service/employeeService.ts

export async function findEmployeeByUserId(id_user: number) {
  return prisma.employee.findFirst({
    where: { id_user: id_user },
    include: {
      user: {
        select: {
          id_user: true,
          username: true,
          email: true,
          role: true
        }
      }
    }
  });
}