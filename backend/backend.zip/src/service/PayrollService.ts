import prisma from "../utils/prisma";

// 1. GET ALL PAYROLL (Admin/HR)
export async function getAllPayroll() {
  return prisma.payroll.findMany({
    include: {
      employee: {
        include: {
          user: {
            select: { id_user: true, username: true, email: true }
          }
        }
      },
      payslip: true
    },
    orderBy: { created_date: 'desc' }
  });
}

// 2. GET PAYROLL BY EMPLOYEE
export async function getPayrollByEmployee(id_employee: number) {
  return prisma.payroll.findMany({
    where: { id_employee },
    include: {
      employee: {
        include: {
          user: true
        }
      },
      payslip: true
    },
    orderBy: { created_date: 'desc' }
  });
}

// 3. GET PAYROLL BY MONTH (periode_month format: "2026-02")
export async function getPayrollByMonth(periode_month: string) {
  return prisma.payroll.findMany({
    where: { periode_month },
    include: {
      employee: {
        include: {
          user: {
            select: { username: true, email: true }
          }
        }
      },
      payslip: true
    },
    orderBy: { total_salary: 'desc' }
  });
}

// 4. CREATE PAYROLL BULK (Generate untuk semua employee periode tertentu)
export async function generatePayroll(periode_month: string) {
  const payrollData = await prisma.$transaction(async (tx) => {
    // Hitung data attendance, leave, overtime per employee
    const employees = await tx.employee.findMany({
      where: { employee_status: 'AKTIF' }
    });

    const payrolls: any[] = [];

    for (const emp of employees) {
      // 1. Total attendance days
      const attendanceCount = await tx.attendance.count({
        where: {
          id_employee: emp.id_employee,
          date: {
            gte: new Date(`${periode_month}-01`),
            lte: new Date(periode_month + '-01T23:59:59')
          },
          attendance_status: 'PRESENT'
        }
      });

      // 2. Total approved leave days
      const approvedLeaves = await tx.leave.groupBy({
        by: ['id_employee'],
        where: {
          id_employee: emp.id_employee,
          start_date: {
            gte: new Date(`${periode_month}-01`)
          },
          leave_status: 'APPROVED'
        },
        _count: { id_leave: true }
      });

      const totalLeaveDays = approvedLeaves[0]?._count.id_leave || 0;

      // 3. Total approved overtime minutes
      const approvedOvertime = await tx.overtime.aggregate({
        where: {
          id_employee: emp.id_employee,
          date: {
            gte: new Date(`${periode_month}-01`)
          },
          overtime_status: 'APPROVED'
        },
        _sum: { total_minutes: true }
      });

      const totalOvertimeMinutes = approvedOvertime._sum.total_minutes || 0;
      const overtimeAllowance = Math.floor(totalOvertimeMinutes / 60) * (emp.basic_salary / 173 / 8 * 1.5); // 1.5x hourly rate

      // 4. Deduction (late + absent)
      const lateCount = await tx.attendance.count({
        where: {
          id_employee: emp.id_employee,
          date: {
            gte: new Date(`${periode_month}-01`)
          },
          attendance_status: 'LATE'
        }
      });

      const absentCount = await tx.attendance.count({
        where: {
          id_employee: emp.id_employee,
          date: {
            gte: new Date(`${periode_month}-01`)
          },
          attendance_status: 'ABSENT'
        }
      });

      const deduction = (lateCount * 50000) + (absentCount * emp.basic_salary / 22);

      // 5. Total salary
      const totalSalary = emp.basic_salary + overtimeAllowance - deduction;

      // Create payroll
      const payroll = await tx.payroll.create({
        data: {
          id_employee: emp.id_employee,
          periode_month,
          total_attendance: attendanceCount,
          total_leave: totalLeaveDays,
          total_overtime: Math.floor(totalOvertimeMinutes / 60),
          deduction,
          total_salary: totalSalary
        },
        include: {
          employee: {
            include: { user: true }
          }
        }
      });

      payrolls.push(payroll);
    }

    return payrolls;
  });

  return payrolls;
}

// 5. GENERATE PAYSLIP untuk payroll tertentu
export async function generatePayslip(id_payroll: number) {
  return prisma.$transaction(async (tx) => {
    const payroll = await tx.payroll.findUnique({
      where: { id_payroll }
    });

    if (!payroll) {
      throw new Error('Payroll not found');
    }

    // Cek apakah payslip sudah ada
    const existingPayslip = await tx.payslip.findUnique({
      where: { id_payroll }
    });

    if (existingPayslip) {
      return existingPayslip;
    }

    // Buat payslip baru
    return tx.payslip.create({
      data: {
        id_payroll,
        net_salary: payroll.total_salary // Bisa ditambah tunjangan lain
      },
      include: {
        payroll: {
          include: {
            employee: true
          }
        }
      }
    });
  });
}

// 6. DOWNLOAD PAYSLIP (mock PDF generation)
export async function downloadPayslip(id_payslip: number) {
  const payslip = await prisma.payslip.findUnique({
    where: { id_payslip },
    include: {
      payroll: {
        include: {
          employee: {
            include: { user: true }
          }
        }
      }
    }
  });

  if (!payslip) {
    throw new Error('Payslip not found');
  }

  // Mock PDF data
  return {
    success: true,
    payslip,
    pdf_url: `/api/payroll/payslip/${id_payslip}/pdf` // Frontend akan hit endpoint ini
  };
}
