import { Request, Response } from "express";
import { UserRole, LeaveStatus, LeaveType } from "@prisma/client";
import * as employeeService from "../service/employeeService";
import * as leaveService from "../service/leaveService";

export async function createLeave(req: Request, res: Response) {
  try {
    const user = req.user!;
    const { leave_type, start_date, end_date, reason } = req.body;
    const file = req.file;

    const employee = await employeeService.findEmployeeByUserId(user.id_user);
    if (!employee) {
      return res.status(400).json({ success: false, message: "Employee not found" });
    }

    const result = await leaveService.createLeave({
      id_employee: employee.id_employee,
      leave_type: leave_type as LeaveType,
      start_date: new Date(start_date),
      end_date: new Date(end_date),
      reason,
      attachment: file ? file.filename : undefined,
    });

    res.json({ success: true, data: result });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function getLeave(req: Request, res: Response) {
  try {
    const user = req.user!;

    if (user.role === UserRole.ADMIN || user.role === UserRole.HR) {
      const list = await leaveService.getAllLeave();
      return res.json({ success: true, data: list });
    }

    const employee = await employeeService.findEmployeeByUserId(user.id_user);
    if (!employee) {
      return res.status(400).json({ success: false, message: "Employee not found" });
    }

    const list = await leaveService.getLeaveByEmployee(employee.id_employee);
    res.json({ success: true, data: list });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function approveLeave(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const user = req.user!;

    const result = await leaveService.updateLeaveStatus(
      Number(id),
      LeaveStatus.APPROVED,
      user.username
    );

    res.json({ success: true, data: result });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function rejectLeave(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const user = req.user!;

    const result = await leaveService.updateLeaveStatus(
      Number(id),
      LeaveStatus.REJECTED,
      user.username
    );

    res.json({ success: true, data: result });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}
