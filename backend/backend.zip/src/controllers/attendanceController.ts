import { Request, Response } from "express";
import { UserRole, AttendanceStatus } from "@prisma/client";
import * as employeeService from "../service/employeeService";
import * as attendanceService from "../service/attendanceService";

function isLate(date: Date) {
  const hour = date.getHours();
  const minute = date.getMinutes();
  // Contoh: Telat jika lewat dari jam 09:00
  if (hour > 9) return true;
  if (hour === 9 && minute > 0) return true;
  return false;
}

export async function checkIn(req: Request, res: Response) {
  try {
    const user = req.user!;
    // Ambil data dari Body dan File (Multer)
    const { latitude, longitude, address } = req.body;
    const photo = req.file; 

    const employee = await employeeService.findEmployeeByUserId(user.id_user);
    if (!employee) return res.status(400).json({ success: false, message: "Employee record not found" });

    const today = new Date();
    const dateOnly = attendanceService.makeDateOnly(today);

    const existing = await attendanceService.findAttendanceForEmployeeOnDate(employee.id_employee, dateOnly);
    if (existing && existing.check_in) {
      return res.status(400).json({ success: false, message: "Already checked in today" });
    }

    const checkInTime = new Date();
    const status = isLate(checkInTime) ? AttendanceStatus.LATE : AttendanceStatus.PRESENT;

    const result = await attendanceService.upsertCheckIn({
      id_employee: employee.id_employee,
      date: dateOnly,
      check_in: checkInTime,
      checkin_latitude: parseFloat(latitude),
      checkin_longitude: parseFloat(longitude),
      checkin_address: address,
      attendance_status: status,
      checkin_photo: photo ? photo.filename : undefined // Simpan nama file foto
    });

    res.json({ success: true, data: result });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function checkOut(req: Request, res: Response) {
  try {
    const user = req.user!;
    const { latitude, longitude, address } = req.body;
    const photo = req.file;

    const employee = await employeeService.findEmployeeByUserId(user.id_user);
    if (!employee) return res.status(400).json({ success: false, message: "Employee not found" });

    const today = new Date();
    const dateOnly = attendanceService.makeDateOnly(today);

    const attendance = await attendanceService.findAttendanceForEmployeeOnDate(employee.id_employee, dateOnly);
    
    if (!attendance || !attendance.check_in) {
      return res.status(400).json({ success: false, message: "No check-in record found for today" });
    }
    if (attendance.check_out) {
      return res.status(400).json({ success: false, message: "Already checked out" });
    }

    const checkOutTime = new Date();
    const duration = Math.max(0, Math.round((checkOutTime.getTime() - new Date(attendance.check_in).getTime()) / 60000));

    const updated = await attendanceService.checkOutAttendance(attendance.id_attendance, {
      check_out: checkOutTime,
      checkout_latitude: parseFloat(latitude),
      checkout_longitude: parseFloat(longitude),
      checkout_address: address,
      work_duration_minutes: duration,
      checkout_photo: photo ? photo.filename : undefined
    });

    res.json({ success: true, data: updated });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function getAttendance(req: Request, res: Response) {
  try {
    const user = req.user!;
    
    if (user.role === UserRole.ADMIN || user.role === UserRole.HR) {
      const list = await attendanceService.listAllAttendance();
      return res.json({ success: true, data: list });
    }

    const employee = await employeeService.findEmployeeByUserId(user.id_user);
    if (!employee) return res.status(400).json({ success: false, message: "Employee not found" });

    const list = await attendanceService.getAttendanceByEmployee(employee.id_employee);
    res.json({ success: true, data: list });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}