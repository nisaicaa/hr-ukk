import { Request, Response } from "express";
import bcrypt from "bcrypt";
import { signToken } from "../utils/jwt";
import { findUserByEmail } from "../service/authService";
import * as userService from "../service/userService";

export async function login(req: Request, res: Response): Promise<void> {
  const { email, password } = req.body as { email: string; password: string };
  if (!email || !password) {
    res.status(400).json({ success: false, message: "Missing credentials" });
    return;
  }

  const user = await findUserByEmail(email);
  if (!user) {
    res.status(401).json({ success: false, message: "Invalid credentials" });
    return;
  }

  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    res.status(401).json({ success: false, message: "Invalid credentials" });
    return;
  }

  const token = signToken({ id_user: user.id_user, role: user.role });

  res.json({
    token,
    user: {
      id_user: user.id_user,
      username: user.username,
      email: user.email,
      role: user.role,
    },
  });
}

export async function register(req: Request, res: Response): Promise<void> {
  const { username, email, password, role } = req.body as { username: string; email: string; password: string; role: string };

  if (!username || !email || !password || !role) {
    res.status(400).json({ success: false, message: "Missing fields" });
    return;
  }

  const existingEmail = await userService.findUserByEmail(email);
  if (existingEmail) {
    res.status(400).json({ success: false, message: "Email already exists" });
    return;
  }

  const existingUsername = await userService.findUserByUsername(username);
  if (existingUsername) {
    res.status(400).json({ success: false, message: "Username already exists" });
    return;
  }

  const hashed = await bcrypt.hash(password, 10);
  const user = await userService.createUser({ username, email, password: hashed, role: role as any });

  res.status(201).json({
    success: true,
    data: { id_user: user.id_user, username: user.username, email: user.email, role: user.role },
  });
}
