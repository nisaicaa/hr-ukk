import { Request, Response } from "express";
import { UserRole } from "@prisma/client";
import * as payrollService from "../service/payrollService";
import * as employeeService from "../service/employeeService";

export async function getAllPayroll(req: Request, res: Response) {
  try {
    const user = req.user!;
    
    if (user.role !== UserRole.ADMIN && user.role !== UserRole.HR && user.role !== UserRole.FINANCE) {
      return res.status(403).json({ success: false, message: "Access denied" });
    }

    const payrolls = await payrollService.getAllPayroll();
    res.json({ success: true, data: payrolls });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function getPayrollByEmployee(req: Request, res: Response) {
  try {
    const user = req.user!;
    const { id_employee } = req.params;

    // Employee bisa lihat payroll sendiri
    const employee = await employeeService.findEmployeeByUserId(user.id_user);
    if (employee && employee.id_employee !== Number(id_employee)) {
      return res.status(403).json({ success: false, message: "Access denied" });
    }

    const payrolls = await payrollService.getPayrollByEmployee(Number(id_employee));
    res.json({ success: true, data: payrolls });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function generatePayroll(req: Request, res: Response) {
  try {
    const user = req.user!;
    
    if (user.role !== UserRole.ADMIN && user.role !== UserRole.HR && user.role !== UserRole.FINANCE) {
      return res.status(403).json({ success: false, message: "Access denied" });
    }

    const { periode_month } = req.body; // Format: "2026-02"

    // Cek apakah sudah ada payroll periode ini
    const existing = await prisma.payroll.findFirst({
      where: { periode_month }
    });

    if (existing) {
      return res.status(400).json({ 
        success: false, 
        message: `Payroll periode ${periode_month} sudah ada` 
      });
    }

    const payrolls = await payrollService.generatePayroll(periode_month);
    res.json({ 
      success: true, 
      message: `${payrolls.length} payroll berhasil digenerate`,
      data: payrolls 
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function generatePayslip(req: Request, res: Response) {
  try {
    const { id_payroll } = req.params;

    const payslip = await payrollService.generatePayslip(Number(id_payroll));
    res.json({ success: true, data: payslip });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function downloadPayslip(req: Request, res: Response) {
  try {
    const { id_payslip } = req.params;
    const result = await payrollService.downloadPayslip(Number(id_payslip));
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}

export async function getPayrollByMonth(req: Request, res: Response) {
  try {
    const { periode_month } = req.query;
    
    if (!periode_month) {
      return res.status(400).json({ success: false, message: "periode_month required" });
    }

    const payrolls = await payrollService.getPayrollByMonth(periode_month as string);
    res.json({ success: true, data: payrolls });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
}
