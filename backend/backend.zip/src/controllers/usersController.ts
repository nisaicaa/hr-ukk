import { Request, Response } from "express";
import bcrypt from "bcrypt";
import { UserRole } from "@prisma/client";
import * as userService from "../service/userService";

export async function listUsers(req: Request, res: Response) {
  const users = await userService.getAllUsers();
  res.json({ success: true, data: users });
}

export async function createUser(req: Request, res: Response) {
  const { username, email, password, role } = req.body as { username: string; email: string; password: string; role: UserRole };
  if (!username || !email || !password || !role) return res.status(400).json({ success: false, message: "Missing fields" });

  const existEmail = await userService.findUserByEmail(email);
  if (existEmail) return res.status(400).json({ success: false, message: "Email already exists" });
  const existUser = await userService.findUserByUsername(username);
  if (existUser) return res.status(400).json({ success: false, message: "Username already exists" });

  const hashed = await bcrypt.hash(password, 10);
  const user = await userService.createUser({ username, email, password: hashed, role });
  res.status(201).json({ success: true, data: { id_user: user.id_user, username: user.username, email: user.email, role: user.role } });
}

export async function updateUser(req: Request, res: Response) {
  const id = Number(req.params.id);
  const { username, email, password, role } = req.body as { username?: string; email?: string; password?: string; role?: UserRole };
  const user = await userService.findUserById(id);
  if (!user) return res.status(404).json({ success: false, message: "User not found" });

  if (email && email !== user.email) {
    const exists = await userService.findUserByEmail(email);
    if (exists) return res.status(400).json({ success: false, message: "Email already in use" });
  }
  if (username && username !== user.username) {
    const exists = await userService.findUserByUsername(username);
    if (exists) return res.status(400).json({ success: false, message: "Username already in use" });
  }

  const data: { username: string; email: string; role: UserRole; password?: string } = {
    username: username ?? user.username,
    email: email ?? user.email,
    role: (role ?? user.role) as UserRole,
  };
  if (password) {
    data.password = await bcrypt.hash(password, 10);
  }

  const updated = await userService.updateUserById(id, data);
  res.json({ success: true, data: { id_user: updated.id_user, username: updated.username, email: updated.email, role: updated.role } });
}

export async function deleteUser(req: Request, res: Response) {
  const id = Number(req.params.id);
  const user = await userService.findUserById(id);
  if (!user) return res.status(404).json({ success: false, message: "User not found" });
  await userService.deleteUserById(id);
  res.json({ success: true, message: "User deleted" });
}
