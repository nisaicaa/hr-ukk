import { Request, Response } from 'express';
import * as employeeService from '../service/employeeService';
import prisma from '../utils/prisma';
import fs from 'fs';
import csv from 'csv-parser';

// 1. GET ALL
export const getEmployees = async (req: Request, res: Response) => {
  try {
    const employees = await employeeService.listEmployees();
    res.json({ success: true, data: employees });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// 2. GET BY ID (Untuk Detail Karyawan)
export const getEmployeeById = async (req: Request, res: Response) => {
  try {
    const id = Number(req.params.id);
    const employee = await prisma.employee.findUnique({
      where: { id_employee: id },
      include: {
        user: {
          select: { id_user: true, username: true, email: true, role: true }
        }
      }
    });

    if (!employee) return res.status(404).json({ success: false, message: "Karyawan tidak ditemukan" });
    res.json({ success: true, data: employee });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// 3. CREATE (Menghubungkan ke User yang sudah ada)
export const createEmployee = async (req: Request, res: Response) => {
  try {
    const { id_user, departemen, jabatan, basic_salary } = req.body;
    
    const data = await prisma.employee.create({
      data: {
        id_user: Number(id_user),
        departemen,
        jabatan,
        basic_salary: Number(basic_salary),
        employee_status: 'AKTIF',
        hire_date: new Date(),
        birth_date: new Date('2000-01-01'),
      },
      include: { user: true }
    });
    res.status(201).json({ success: true, data });
  } catch (error: any) {
    res.status(400).json({ success: false, error: error.message });
  }
};

// 4. UPDATE
export const updateEmployee = async (req: Request, res: Response) => {
  try {
    const id = Number(req.params.id);
    const { username, email, departemen, jabatan, basic_salary, employee_status } = req.body;
    
    // Memanggil service transaction agar data User & Employee sinkron
    const data = await employeeService.updateEmployeeById(id, {
      nik: username, // mapping dari form frontend
      email,
      departemen,
      jabatan,
      basic_salary,
      employee_status
    });

    res.json({ success: true, data });
  } catch (error: any) {
    res.status(400).json({ success: false, error: error.message });
  }
};

// 5. DELETE
export const deleteEmployee = async (req: Request, res: Response) => {
  try {
    const id = Number(req.params.id);
    await prisma.employee.delete({ where: { id_employee: id } });
    res.json({ success: true, message: "Karyawan berhasil dihapus" });
  } catch (error: any) {
    res.status(400).json({ success: false, error: error.message });
  }
};

// 6. BULK IMPORT (Logic CSV)
export const bulkImport = async (req: Request, res: Response) => {
  const filePath = req.file?.path;
  if (!filePath) return res.status(400).json({ error: 'File tidak ditemukan' });

  const results: any[] = [];
  const errors: string[] = [];

  try {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const delimiter = fileContent.includes(';') ? ';' : ',';
    const stream = fs.createReadStream(filePath).pipe(csv({ separator: delimiter }));

    for await (const row of stream) {
      try {
        await employeeService.createEmployeeWithUser({
          nik: (row.nik || row.username).trim(),
          email: row.email.trim(),
          departemen: row.departemen || 'Umum',
          jabatan: row.jabatan || 'Staff',
          basic_salary: parseInt(row.basic_salary?.replace(/[^0-9]/g, '')) || 0
        });
        results.push(row);
      } catch (err: any) {
        errors.push(err.message);
      }
    }
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    res.json({ success: true, summary: `${results.length} Berhasil`, errors });
  } catch (error: any) {
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    res.status(500).json({ error: error.message });
  }
};
