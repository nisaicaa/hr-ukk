import { useState } from 'react';
import { getUser } from '../../../../services/helper/auth';
import { User, Mail, Shield, Save } from 'lucide-react';
import apiClient from '../../../../services/api';
import { handleError } from '../../../../services/handler/error';

const AccountSettings = () => {
  const currentUser = getUser();
  const [formData, setFormData] = useState({
    username: currentUser?.username || '',
    email: currentUser?.email || '',
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    setSaving(true);
    setMessage({ type: '', text: '' });

    try {
      const updateData: any = {
        username: formData.username,
        email: formData.email,
      };

      await apiClient.put(`/users/${currentUser?.id_user}`, updateData);
      
      setMessage({ type: 'success', text: 'Profil berhasil diperbarui!' });
    } catch (error) {
      setMessage({ type: 'error', text: handleError(error) });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 px-2">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Profile Saya</h1>
        <p className="text-sm text-slate-500 mt-1">Informasi pribadi Anda di sistem HumaNest</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-200">
            <div className="text-center">
              <div className="relative inline-block mb-6">
                <div className="w-24 h-24 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-200">
                  <span className="text-white text-3xl font-black">
                    {currentUser?.username.charAt(0).toUpperCase()}
                  </span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-900">{currentUser?.username}</h3>
              <p className="text-sm text-slate-500 mb-6">{currentUser?.email}</p>
              <div className="inline-flex items-center px-4 py-1.5 rounded-xl text-xs font-bold bg-emerald-50 text-emerald-600 border border-emerald-100">
                <Shield size={14} className="mr-2" />
                ROLE: {currentUser?.role}
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-slate-400 uppercase tracking-widest">Status Akun</span>
                <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] bg-emerald-50 text-emerald-600 uppercase">
                  AKTIF
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Settings Form */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-200">
            <h2 className="text-lg font-bold text-slate-900 mb-6">Informasi Akun</h2>

            {message.text && (
              <div className={`mb-6 p-4 rounded-xl text-sm font-medium ${
                message.type === 'success' 
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                  : 'bg-rose-50 text-rose-700 border border-rose-200'
              }`}>
                {message.text}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
                    <User size={14} className="text-slate-400" />
                    Username
                  </label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition-all font-medium text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
                    <Mail size={14} className="text-slate-400" />
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition-all font-medium text-slate-900"
                    required
                  />
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={saving}
                  className="flex items-center justify-center gap-2 px-8 py-3.5 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all disabled:opacity-50 shadow-lg shadow-emerald-200 disabled:shadow-none"
                >
                  <Save size={18} />
                  {saving ? 'Menyimpan...' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSettings;
