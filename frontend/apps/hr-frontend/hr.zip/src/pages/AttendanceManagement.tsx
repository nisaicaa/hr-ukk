import { useEffect, useState } from 'react';
import apiClient from '../../../../services/api';
import { 
  Search, Eye, MapPin, X, FileSpreadsheet, 
  ArrowRight, Users, Clock, AlertCircle, CheckCircle
} from 'lucide-react';

const AttendanceManagement = () => {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedRow, setSelectedRow] = useState<any>(null);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      const res = await apiClient.get('/attendance');
      setData(res.data.data || []);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const filteredData = data.filter(item => 
    item.employee?.user?.username?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // LOGIC SUMMARY (Sesuai permintaan)
  const totalPresent = data.filter(a => a.attendance_status === 'PRESENT').length;
  const totalLate = data.filter(a => a.attendance_status === 'LATE').length;

  if (loading) return <div className="p-10 text-center font-black text-slate-400 animate-pulse">LOADING...</div>;

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      
      {/* HEADER SECTION (Style EmployeeManagement) */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-8 rounded-[35px] border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight italic uppercase">Manajemen Absensi</h2>
          <p className="text-sm font-bold text-slate-400">Monitoring kehadiran karyawan harian</p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-72">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
            <input 
              type="text" 
              placeholder="Cari nama karyawan..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border-none rounded-2xl text-sm font-bold focus:ring-2 focus:ring-emerald-500 transition-all"
            />
          </div>
        </div>
      </div>

      {/* SUMMARY CARDS (Style EmployeeManagement) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-[35px] border border-slate-200 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center shadow-inner"><Users size={24}/></div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Record</p>
            <p className="text-2xl font-black text-slate-800">{data.length}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-[35px] border border-slate-200 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center shadow-inner"><CheckCircle size={24}/></div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Hadir Tepat Waktu</p>
            <p className="text-2xl font-black text-slate-800">{totalPresent}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-[35px] border border-slate-200 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center shadow-inner"><AlertCircle size={24}/></div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Terlambat</p>
            <p className="text-2xl font-black text-slate-800">{totalLate}</p>
          </div>
        </div>
      </div>

      {/* TABLE SECTION */}
      <div className="bg-white border border-slate-200 rounded-[40px] overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 border-b border-slate-100">
              <tr>
                <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Karyawan</th>
                <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Jam Masuk</th>
                <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Jam Pulang</th>
                <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredData.map((row, i) => (
                <tr key={i} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-11 h-11 bg-slate-100 text-slate-500 rounded-2xl flex items-center justify-center font-black text-xs border border-slate-200">
                        {row.employee?.user?.username?.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-bold text-slate-700">{row.employee?.user?.username}</p>
                        <p className="text-[10px] font-medium text-slate-400 italic">{new Date(row.date).toLocaleDateString('id-ID')}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-6">
                    <span className="text-sm font-black text-emerald-600 tabular-nums">
                      {row.check_in ? new Date(row.check_in).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '--:--'}
                    </span>
                  </td>
                  <td className="p-6">
                    <span className="text-sm font-black text-rose-500 tabular-nums">
                      {row.check_out ? new Date(row.check_out).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '--:--'}
                    </span>
                  </td>
                  <td className="p-6 text-center">
                    <button 
                      onClick={() => { setSelectedRow(row); setShowDetailModal(true); }}
                      className="p-3 bg-slate-50 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition border border-slate-100 shadow-sm"
                    >
                      <Eye size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL DETAIL */}
      {showDetailModal && selectedRow && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-lg rounded-[45px] overflow-hidden shadow-2xl animate-in zoom-in-95">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="text-xl font-black text-slate-800 italic uppercase">Log Presensi</h3>
              <button onClick={() => setShowDetailModal(false)} className="p-2 hover:bg-white rounded-xl transition text-slate-300"><X size={20}/></button>
            </div>
            <div className="p-8 space-y-6">
               <div className="aspect-video w-full bg-slate-100 rounded-[35px] border-4 border-white shadow-xl overflow-hidden">
                  <img src={selectedRow.checkin_photo} className="w-full h-full object-cover" alt="Selfie" />
               </div>
               <div className="flex items-center gap-4 p-6 bg-blue-50 rounded-[30px] border border-blue-100">
                  <div className="p-3 bg-white rounded-2xl text-blue-600 shadow-sm"><MapPin size={24}/></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[9px] font-black text-blue-400 uppercase mb-1">Titik Lokasi</p>
                    <p className="text-xs font-bold text-blue-800 line-clamp-1">{selectedRow.checkin_address || 'Lokasi tidak terekam'}</p>
                  </div>
                  <button onClick={() => window.open(`https://www.google.com/maps?q=${selectedRow.checkin_latitude},${selectedRow.checkin_longitude}`)} className="p-3 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-200"><ArrowRight size={20}/></button>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceManagement;