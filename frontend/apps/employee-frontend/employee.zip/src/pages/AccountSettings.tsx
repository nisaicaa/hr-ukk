import { useState } from 'react';
import { getUser } from '../../../../services/helper/auth';
import { User, Mail, Shield, Save, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import apiClient from '../../../../services/api';
import { handleError } from '../../../../services/handler/error';

const AccountSettings = () => {
  const navigate = useNavigate();
  const currentUser = getUser();
  const [formData, setFormData] = useState({
    username: currentUser?.username || '',
    email: currentUser?.email || '',
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    setSaving(true);
    setMessage({ type: '', text: '' });

    try {
      const updateData: any = {
        username: formData.username,
        email: formData.email,
      };

      await apiClient.put(`/users/${currentUser?.id_user}`, updateData);
      
      setMessage({ type: 'success', text: 'Profil berhasil diperbarui!' });
    } catch (error) {
      setMessage({ type: 'error', text: handleError(error) });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <div className="bg-white border-b border-slate-100 px-4 py-4 flex items-center gap-4 sticky top-0 z-10">
        <button 
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-slate-50 rounded-xl transition-colors"
        >
          <ArrowLeft size={20} className="text-slate-600" />
        </button>
        <h1 className="font-bold text-slate-800 text-lg">Profile Saya</h1>
      </div>

      <div className="p-6 md:p-8 space-y-6 md:space-y-8 max-w-4xl mx-auto w-full">
        {/* Profile Card */}
        <div className="bg-white rounded-[28px] p-8 md:p-10 shadow-sm border border-slate-100">
          <div className="text-center">
            <div className="relative inline-block mb-6">
              <div className="w-24 h-24 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-[24px] flex items-center justify-center shadow-lg shadow-emerald-200 rotate-3">
                <span className="text-white text-3xl font-black -rotate-3">
                  {currentUser?.username.charAt(0).toUpperCase()}
                </span>
              </div>
            </div>
            <h3 className="text-xl font-bold text-slate-900">{currentUser?.username}</h3>
            <p className="text-sm text-slate-500 mb-4">{currentUser?.email}</p>
            <div className="inline-flex items-center px-4 py-1.5 rounded-xl text-[10px] font-black bg-emerald-50 text-emerald-600 border border-emerald-100 uppercase tracking-widest">
              <Shield size={14} className="mr-2" />
              {currentUser?.role}
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-100">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-400 uppercase tracking-widest">Status</span>
              <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] bg-emerald-50 text-emerald-600 uppercase">
                AKTIF
              </span>
            </div>
          </div>
        </div>

        {/* Settings Form */}
        <div className="bg-white rounded-[28px] p-8 md:p-10 shadow-sm border border-slate-100">
          <h2 className="text-lg font-bold text-slate-900 mb-6">Informasi Akun</h2>

          {message.text && (
            <div className={`mb-6 p-4 rounded-xl text-sm font-medium ${
              message.type === 'success' 
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                : 'bg-rose-50 text-rose-700 border border-rose-200'
            }`}>
              {message.text}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                  <User size={14} />
                  Username
                </label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition-all font-medium text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                  <Mail size={14} />
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition-all font-medium text-slate-900"
                  required
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={saving}
                className="w-full md:w-auto flex items-center justify-center gap-2 px-8 py-4 bg-slate-900 text-white font-bold rounded-2xl hover:bg-slate-800 disabled:bg-slate-400 disabled:cursor-not-allowed transition-all active:scale-[0.98] shadow-lg"
              >
                <Save size={18} />
                {saving ? 'Menyimpan...' : 'Simpan Perubahan'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AccountSettings;
