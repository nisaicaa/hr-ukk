import { useEffect, useState } from 'react';
import apiClient from '../../../../services/api';
import { 
  Calendar, Clock, AlertCircle, CheckCircle, 
  ChevronLeft, ChevronRight, MapPin, Eye, X
} from 'lucide-react';

const MyAttendance = () => {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDetail, setShowDetail] = useState<any>(null);

  useEffect(() => {
    fetchMyAttendance();
  }, []);

  const fetchMyAttendance = async () => {
    try {
      const res = await apiClient.get('/attendance');
      // Pastikan data yang diambil adalah array
      const attendanceData = Array.isArray(res.data.data) ? res.data.data : [];
      setData(attendanceData);
    } catch (e) {
      console.error("Fetch Error:", e);
      setData([]); // Set array kosong jika error agar tidak crash
    } finally {
      setLoading(false);
    }
  };

  // Logic Hitung Statistik (Safe Check)
  const stats = {
    present: data.filter(a => a?.attendance_status === 'PRESENT').length,
    late: data.filter(a => a?.attendance_status === 'LATE').length,
    total: data.length
  };

  // Fungsi Helper Format Jam agar tidak error
  const formatTime = (timeString: string | null) => {
    if (!timeString) return '--:--';
    try {
      return new Date(timeString).toLocaleTimeString('id-ID', { 
        hour: '2-digit', 
        minute: '2-digit' 
      });
    } catch (e) {
      return '--:--';
    }
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-[400px] animate-pulse">
      <div className="w-12 h-12 border-4 border-slate-200 border-t-emerald-600 rounded-full animate-spin mb-4"></div>
      <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Memuat Riwayat...</p>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12 animate-in fade-in duration-700">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-center bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-800 tracking-tighter italic uppercase">My Attendance</h2>
          <p className="text-sm font-bold text-slate-400 mt-1 tracking-tight">Rekapitulasi kehadiran pribadi Anda</p>
        </div>
        <div className="bg-slate-900 text-white px-8 py-4 rounded-[25px] shadow-lg">
           <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60 block mb-1 text-center">Periode</span>
           <span className="text-sm font-black uppercase tracking-widest">
             {new Intl.DateTimeFormat('id-ID', { month: 'long', year: 'numeric' }).format(new Date())}
           </span>
        </div>
      </div>

      {/* SUMMARY STATS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-[45px] border border-slate-200 shadow-sm flex items-center gap-6">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-[25px] flex items-center justify-center shadow-inner"><Calendar size={28}/></div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Record</p>
            <p className="text-3xl font-black text-slate-800 tabular-nums">{stats.total}</p>
          </div>
        </div>
        <div className="bg-white p-8 rounded-[45px] border border-slate-200 shadow-sm flex items-center gap-6">
          <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-[25px] flex items-center justify-center shadow-inner"><CheckCircle size={28}/></div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tepat Waktu</p>
            <p className="text-3xl font-black text-slate-800 tabular-nums">{stats.present}</p>
          </div>
        </div>
        <div className="bg-white p-8 rounded-[45px] border border-slate-200 shadow-sm flex items-center gap-6">
          <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-[25px] flex items-center justify-center shadow-inner"><AlertCircle size={28}/></div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Terlambat</p>
            <p className="text-3xl font-black text-slate-800 tabular-nums">{stats.late}</p>
          </div>
        </div>
      </div>

      {/* TABLE */}
      <div className="bg-white border border-slate-200 rounded-[50px] overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 border-b border-slate-100">
              <tr>
                <th className="p-7 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Tanggal</th>
                <th className="p-7 text-[10px] font-black text-slate-400 uppercase tracking-widest">Check In</th>
                <th className="p-7 text-[10px] font-black text-slate-400 uppercase tracking-widest">Check Out</th>
                <th className="p-7 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                <th className="p-7 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {data.length > 0 ? data.map((row, i) => (
                <tr key={i} className="hover:bg-slate-50/30 transition-colors">
                  <td className="p-7">
                    <div className="text-center">
                      <p className="text-sm font-black text-slate-700">{row.date ? new Date(row.date).getDate() : '-'}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase">
                        {row.date ? new Intl.DateTimeFormat('id-ID', { month: 'short' }).format(new Date(row.date)) : ''}
                      </p>
                    </div>
                  </td>
                  <td className="p-7 font-black text-emerald-600 tabular-nums">
                    {formatTime(row.check_in)}
                  </td>
                  <td className="p-7 font-black text-rose-500 tabular-nums">
                    {formatTime(row.check_out)}
                  </td>
                  <td className="p-7">
                    <span className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-tighter ${row.attendance_status === 'PRESENT' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                      {row.attendance_status || 'N/A'}
                    </span>
                  </td>
                  <td className="p-7 text-center">
                    <button 
                      onClick={() => setShowDetail(row)}
                      className="p-3 bg-slate-50 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-2xl transition border border-slate-100 shadow-sm"
                    >
                      <Eye size={18} />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="p-10 text-center font-bold text-slate-400 italic">Belum ada data absensi bulan ini.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* DETAIL MODAL */}
      {showDetail && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-[50px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/30">
              <h3 className="text-xl font-black text-slate-800 italic uppercase">Evidence</h3>
              <button onClick={() => setShowDetail(null)} className="p-2 hover:bg-white rounded-xl transition text-slate-300"><X size={20}/></button>
            </div>
            <div className="p-8 space-y-6">
              <div className="aspect-square w-full bg-slate-100 rounded-[40px] border-4 border-white shadow-xl overflow-hidden">
                {showDetail.checkin_photo ? (
                  <img src={showDetail.checkin_photo} className="w-full h-full object-cover" alt="Selfie" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400 font-bold italic">No Photo</div>
                )}
              </div>
              <div className="bg-slate-50 p-6 rounded-[35px] border border-slate-100 flex items-center gap-4">
                <div className="p-4 bg-white rounded-2xl text-rose-500 shadow-sm"><MapPin size={24}/></div>
                <div className="min-w-0 flex-1">
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Lokasi Presensi</p>
                  <p className="text-xs font-bold text-slate-700 line-clamp-2 italic">{showDetail.checkin_address || 'Alamat tidak tersedia'}</p>
                </div>
              </div>
              <button onClick={() => setShowDetail(null)} className="w-full py-5 bg-slate-900 text-white rounded-[25px] font-black uppercase text-[10px] tracking-[0.2em] shadow-lg shadow-slate-200 active:scale-95 transition">Tutup Log</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyAttendance;