import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom'; // Tambahkan Link
import { 
  Calendar, Camera, FileText, MapPin, 
  Loader2, LogIn, LogOut, Send, Clock
} from 'lucide-react';
import apiClient from '../../../../services/api';
import { getUser } from '../../../../services/helper/auth';
import { handleError } from '../../../../services/handler/error';
import { showSuccess, showError, showToast } from '../../../../services/helper/swal';

const Dashboard = () => {
  const [time, setTime] = useState(new Date());
  const [loading, setLoading] = useState(false);
  const [attendanceToday, setAttendanceToday] = useState<any>(null);
  const [location, setLocation] = useState<{lat: number, lng: number, address: string} | null>(null);
  const user = getUser();
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<File | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    fetchAttendance();
    getCurrentLocation();
    return () => clearInterval(timer);
  }, []);

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(async (pos) => {
          const { latitude, longitude } = pos.coords;
          try {
            const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
            const data = await res.json();
            setLocation({ lat: latitude, lng: longitude, address: data.display_name });
          } catch {
            setLocation({ lat: latitude, lng: longitude, address: "Lokasi Berhasil Dilock" });
          }
        },
        () => showToast("Aktifkan GPS!", "error"),
        { enableHighAccuracy: true }
      );
    }
  };

  const fetchAttendance = async () => {
    try {
      const res = await apiClient.get('/attendance');
      const todayStr = new Date().toLocaleDateString('en-CA'); 
      const todayData = res.data.data?.find((a: any) => a.date.startsWith(todayStr));
      setAttendanceToday(todayData || null);
    } catch (e) { console.error(e); }
  };

  const handleAttendance = async (type: 'in' | 'out') => {
    if (!capturedPhoto) {
      showToast("Ambil foto selfie!", "error");
      fileInputRef.current?.click();
      return;
    }
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('photo', capturedPhoto);
      formData.append('latitude', location?.lat.toString() || '');
      formData.append('longitude', location?.lng.toString() || '');
      formData.append('address', location?.address || '');

      const endpoint = type === 'in' ? '/attendance/check-in' : '/attendance/check-out';
      await apiClient.post(endpoint, formData);
      showSuccess("Berhasil", `Absen ${type === 'in' ? 'Masuk' : 'Pulang'} Sukses.`);
      setCapturedPhoto(null);
      fetchAttendance();
    } catch (e: any) {
      showError("Gagal", handleError(e));
    } finally {
      setLoading(false);
    }
  };

  // Definisi Menu agar lebih rapi
  const menuCards = [
    { label: 'My Attendance', icon: Calendar, color: 'text-emerald-600', bg: 'bg-emerald-50', link: '/my-attendance' },
    { label: 'Leave / Permit', icon: Send, color: 'text-amber-600', bg: 'bg-amber-50', link: '/dashboard/leave' },
    { label: 'My Payslip', icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50', link: '/dashboard/payslip' },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12 animate-in fade-in duration-700">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-center bg-white p-10 rounded-[45px] border border-slate-200 shadow-sm gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tighter italic">Halo, {user?.username}!</h2>
          <p className="text-sm font-bold text-slate-400 mt-1 uppercase tracking-widest">Aplikasi Manajemen HR & Absensi</p>
        </div>
        <div className="text-center md:text-right bg-slate-900 text-white py-5 px-10 rounded-[35px] shadow-xl shadow-slate-200 min-w-[240px]">
          <p className="text-4xl font-black tabular-nums tracking-tighter">{time.toLocaleTimeString('id-ID')}</p>
          <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-50 mt-1 italic">
            {new Intl.DateTimeFormat('id-ID', { dateStyle: 'full' }).format(time)}
          </p>
        </div>
      </div>

      {/* ATTENDANCE CARD */}
      <div className="bg-white border border-slate-200 rounded-[55px] p-10 shadow-sm relative overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={`aspect-video w-full rounded-[40px] border-4 border-dashed flex flex-col items-center justify-center transition-all cursor-pointer overflow-hidden ${capturedPhoto ? 'bg-emerald-50 border-emerald-400 text-emerald-600' : 'bg-slate-50 border-slate-200 text-slate-300 hover:border-emerald-300'}`}
            >
              {capturedPhoto ? (
                <div className="text-center">
                  <Camera size={40} className="mx-auto mb-2 opacity-60" />
                  <p className="text-[10px] font-black uppercase tracking-widest">Selfie Berhasil Diambil</p>
                </div>
              ) : (
                <div className="text-center">
                  <Camera size={48} className="mx-auto mb-4" strokeWidth={1.5} />
                  <p className="text-[10px] font-black uppercase tracking-widest">Ambil Foto Selfie</p>
                </div>
              )}
              <input type="file" ref={fileInputRef} onChange={(e) => e.target.files?.[0] && setCapturedPhoto(e.target.files[0])} accept="image/*" capture="user" className="hidden" />
            </div>

            <div className="flex items-center gap-4 p-6 bg-slate-50 rounded-[30px] border border-slate-100">
              <div className="p-4 bg-white rounded-2xl shadow-sm text-rose-500 shadow-inner"><MapPin size={24} /></div>
              <div className="flex-1 min-w-0">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Alamat Terdeteksi</p>
                <p className="text-sm font-bold text-slate-700 truncate italic">{location?.address || "Mencari koordinat..."}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            <button 
              onClick={() => handleAttendance('in')}
              disabled={loading || !!attendanceToday?.check_in}
              className="py-12 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-100 text-white disabled:text-slate-400 rounded-[45px] font-black text-2xl tracking-[0.1em] transition-all shadow-2xl shadow-emerald-100 active:scale-95 flex items-center justify-center gap-4"
            >
              {loading ? <Loader2 className="animate-spin" /> : <><LogIn size={32} /> CHECK IN</>}
            </button>
            <button 
              onClick={() => handleAttendance('out')}
              disabled={loading || !attendanceToday?.check_in || !!attendanceToday?.check_out}
              className="py-12 bg-slate-900 hover:bg-black disabled:bg-slate-100 text-white disabled:text-slate-400 rounded-[45px] font-black text-2xl tracking-[0.1em] transition-all shadow-2xl shadow-slate-200 active:scale-95 flex items-center justify-center gap-4"
            >
              {loading ? <Loader2 className="animate-spin" /> : <><LogOut size={32} /> CHECK OUT</>}
            </button>
          </div>
        </div>
      </div>

      {/* SQUARE BENTO MENU: Sekarang Menggunakan Link */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {menuCards.map((item, i) => (
          <Link 
            key={i} 
            to={item.link}
            className="aspect-square bg-white border border-slate-200 p-8 rounded-[45px] flex flex-col items-center justify-center gap-5 hover:shadow-2xl hover:-translate-y-2 transition-all group active:scale-95 shadow-sm"
          >
            <div className={`w-24 h-24 ${item.bg} ${item.color} rounded-[35px] flex items-center justify-center group-hover:scale-110 transition-transform shadow-inner`}>
              <item.icon size={40} />
            </div>
            <span className="font-black text-[11px] text-slate-500 uppercase tracking-[0.2em] italic">{item.label}</span>
          </Link>
        ))}
      </div>

    </div>
  );
};

export default Dashboard;