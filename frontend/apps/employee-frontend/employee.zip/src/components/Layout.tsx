import { Outlet, useNavigate } from "react-router-dom";
import { User, Bell } from "lucide-react";

const Layout = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#FDFDFD]">
      {/* HEADER MINIMALIS */}
      <header className="h-28 bg-emerald-600 flex items-center justify-between px-10 sticky top-0 z-50">
        <div className="flex items-center">
          {/* LOGO MAKSIMAL */}
          <img 
            src="/logo.png" 
            alt="Logo" 
            className="h-24 w-auto object-contain brightness-0 invert transition-transform active:scale-95" 
          />
        </div>
        
        <div className="flex items-center gap-2">
          {/* Ikon Notifikasi Bersih */}
          <button className="p-4 text-white/80 hover:text-white hover:bg-white/10 rounded-2xl transition-all relative active:bg-white/20">
            <Bell size={28} />
            <span className="absolute top-4 right-4 w-2.5 h-2.5 bg-amber-400 rounded-full border-2 border-emerald-600"></span>
          </button>
          
          {/* Ikon Profil Bersih (Tanpa Box Putih Awal) */}
          <button 
            onClick={() => navigate('/account-settings')}
            className="p-4 text-white/80 hover:text-white hover:bg-white/10 rounded-2xl transition-all active:bg-white/20"
          >
            <User size={30} />
          </button>
        </div>
      </header>

      {/* Konten Utama */}
      <main className="max-w-6xl mx-auto p-12">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;